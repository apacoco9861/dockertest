该工程是Tars框架文档相关介绍，其他功能文档请到各个语言，如cpp、java、nodejs等目录下的docs查看

名称 |功能
------------------|----------------
[tars_http.md](https://github.com/TarsCloud/Tars/blob/master/docs/tars_http.md)                |Tars框架支持http2协议功能说明
[tars_idc_set.md](https://github.com/TarsCloud/Tars/blob/master/docs/tars_idc_set.md)             |Tars框架IDC分组和Set分组说明文档
[tars_openssl.md](https://github.com/TarsCloud/Tars/blob/master/docs/tars_openssl.md)             |Tars框架支持https协议功能说明
[tars_performce.md](https://github.com/TarsCloud/Tars/blob/master/docs/tars_performce.md)           |Tars框架性能测试说明文档
[tars_tracing.md](https://github.com/TarsCloud/Tars/blob/master/docs/tars_tracing.md)             |Tars框架调用链使用说明
[tars_auth.md](https://github.com/TarsCloud/Tars/blob/master/docs/tars_auth.md)                |Tars鉴权功能
