```
Step:
1.install mysql on your machine, and change the db infomation in comm.properties.
2.use this script to checkout the code
	cd /data
	git clone https://github.com/TarsCloud/Tars.git --recursive
	cd /data/Tars/deploy
	python ./deploy.py all

Attention:
1.support with python 2.7
2.network unobstructed
3.you had installed :gcc,gcc-c++,cmake,yasm,glibc-devel,flex,bison,ncurses-devel,zlib-devel,autoconf ,if not ,we will install it ,but It's possible to fail.
4.Tars uses /usr/local/mysql/ as default path. If yours is not this, please modify the file CMakeLists.txt(framework/tarscpp/CMakeLists.txt, framework/CMakeLists.txt) before compile. 
```
