Documents for Tars. For other functional documents, please go to docs-en in various languages, such as cpp, java, nodejs, etc.

name |function
------------------|----------------
[tars_http.md](https://github.com/TarsCloud/Tars/blob/master/docs-en/tars_http.md)                |Tars support http2
[tars_idc_set.md](https://github.com/TarsCloud/Tars/blob/master/docs-en/tars_idc_set.md)             |Tars idc & set grouping
[tars_tracing.md](https://github.com/TarsCloud/Tars/blob/master/docs-en/tars_tracing.md)             |Tars support tracing
